#pragma once
#include <string>
using std::string;

#include <vector>
using std::vector;

#include <array>
using std::array;

#define GRID_SIZE 6
#define MAX_HITS 12

class Battleship
{
    public:
        Battleship();
        void PlaceShips();
        bool CheckMove(string);
        bool CheckWin();
        void PrintBoard();
        
    private:
    void SetShip(int, int, int, int, int);
    bool CheckPosition(int, int);
    vector<int> SplitMove(string);
    int num_hits;
    bool won;
    array<array<int, GRID_SIZE>, GRID_SIZE> board;
};
