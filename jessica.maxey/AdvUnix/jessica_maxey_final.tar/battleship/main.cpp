#include "battle.h"

int main()
{
    Battleship battleship;
    
    battleship.PlaceShips();
 
    battleship.PrintBoard();
   
    battleship.CheckMove("1, 5");
    
    battleship.PrintBoard();
    
    battleship.CheckMove("1, 6");
    battleship.PrintBoard();
    
    battleship.CheckMove("4, 3");
    battleship.CheckMove("4, 4");
    battleship.CheckMove("4, 5");
    battleship.PrintBoard();
    
    battleship.CheckMove("4, 6");
    battleship.CheckMove("5, 6");
    battleship.CheckMove("6, 6");
    battleship.PrintBoard();
    
    battleship.CheckMove("2, 2");
    battleship.CheckMove("3, 2");
    battleship.CheckMove("4, 2");
    battleship.CheckMove("5, 2");
    
    battleship.PrintBoard();
    
    return 0;
}