#include <utility>
using std::pair;

#include <vector>
using std::vector;

#include <sstream>
using std::stringstream;

#include <iostream>
using std::cout;
using std::cin;
using std::endl;

#include "battle.h" 
#include "main.h"
Battleship::Battleship()
{
    num_hits = 0;
    won = false;
    board = {{{0,0,0,0,0,0},
        {0,0,0,0,0,0},
        {0,0,0,0,0,0},
        {0,0,0,0,0,0},
        {0,0,0,0,0,0},
        {0,0,0,0,0,0}}};
}

void Battleship::SetShip(int first_start, int first_end, int second_start, 
        int second_end, int num_ship)
{
    if(first_start == second_start)
    {
        int biggest = 0;
        int smallest = 0;

        if(first_end > second_end)
        {
            biggest = first_end;
            smallest = second_end;
        }
        else
        {
            biggest = second_end;
            smallest = first_end;
        }

        for (int i = smallest; i <= biggest; i++)
        {
            board[first_start][i] = num_ship;
        }

    }
    else if(first_end == second_end)
    {
        int biggest = 0;
        int smallest = 0;

        if(first_start > second_start)
        {
            biggest = first_start;
            smallest = second_start;
        }
        else
        {
            biggest = second_start;
            smallest = first_start;
        }

        for (int i = smallest; i <= biggest; i++)
        {
            board[i][first_end] = num_ship;
        }
    }
    else
        cout << "Error" << endl;
}

void Battleship::PlaceShips()
{
    hook = true;
    pair<int, int> two_hit_start;
    pair<int, int> two_hit_end;
    pair<int, int> three_hit_1_start;
    pair<int, int> three_hit_1_end;
    pair<int, int> three_hit_2_start;
    pair<int, int> three_hit_2_end;
    pair<int, int> four_hit_start;
    pair<int, int> four_hit_end;

    bool repeat = true;
    int num_ship = 1;

    cout << "6x6 grid, enter a numeric positions (ex: 1, 1) first being col, second being row\n";

    while(repeat == true)
    {
        if(repeat == true)
        {
            cout << "Enter starting first position for two hit ship: " << endl;
            cin2 >> two_hit_start.first;

            cout << "Enter starting second position for two hit ship: " << endl;
            cin2 >> two_hit_start.second;

            if((repeat = CheckPosition(two_hit_start.first, 
                            two_hit_start.second)) == true)
                break;

            repeat = true;
            
            cout << "Enter ending first position for two hit ship: ";
            cin2 >> two_hit_end.first;

            cout << "Enter ending second position for two hit ship: ";
            cin2 >> two_hit_end.second;
            
            if((repeat = CheckPosition(two_hit_end.first, 
                            two_hit_end.second)) == true)
                break;
        
            SetShip(two_hit_start.first - 1, two_hit_start.second - 1, 
                two_hit_end.first - 1, two_hit_end.second - 1, num_ship);

            num_ship++;
        }
    }

    repeat = true;

    while(repeat == true)
    {
        if(repeat == true)
        {
            cout << "Enter starting first position for first three hit ship: ";
            cin2 >> three_hit_1_start.first;

            cout << "Enter starting second position for first three hit ship: ";
            cin2 >> three_hit_1_start.second;

            if((repeat = CheckPosition(three_hit_1_start.first, 
                            three_hit_1_start.second)) == true)
                break;
            
            repeat = true;
            
            cout << "Enter ending first position for first three hit ship: ";
            cin2 >> three_hit_1_end.first;

            cout << "Enter ending second position for first three hit ship: ";
            cin2 >> three_hit_1_end.second;
            
            if((repeat = CheckPosition(three_hit_1_end.first, 
                            three_hit_1_end.second)) == true)
                break;
        
            SetShip(three_hit_1_start.first - 1, three_hit_1_start.second - 1, 
                three_hit_1_end.first - 1, three_hit_1_end.second - 1, num_ship);

            num_ship++;
        }
    }

    repeat = true;
    
    while(repeat == true)
    {
        if(repeat == true)
        {
            cout << "Enter starting first position for second three hit ship: ";
            cin2 >> three_hit_2_start.first;

            cout << "Enter starting second position for second three hit ship: ";
            cin2 >> three_hit_2_start.second;

            if((repeat = CheckPosition(three_hit_2_start.first, 
                            three_hit_2_start.second)) == true)
                break;
            
            repeat = true;

            cout << "Enter ending first position for second three hit ship: ";
            cin2 >> three_hit_2_end.first;

            cout << "Enter ending second position for second three hit ship: ";
            cin2 >> three_hit_2_end.second;
            
            if((repeat = CheckPosition(three_hit_2_end.first, 
                            three_hit_2_end.second)) == true)
                break;
        
            SetShip(three_hit_2_start.first - 1, three_hit_2_start.second - 1, 
                three_hit_2_end.first - 1, three_hit_2_end.second - 1, num_ship);

            num_ship++;
        }
    }

    repeat = true;
    
    while(repeat == true)
    {
        if(repeat == true)
        {
            cout << "Enter starting first position for four hit ship: ";
            cin2 >> four_hit_start.first;

            cout << "Enter starting second position for four hit ship: ";
            cin2 >> four_hit_start.second;

            if((repeat = CheckPosition(four_hit_start.first, 
                            four_hit_start.second)) == true)
                break;

            repeat = true;
            
            cout << "Enter ending first position for four hit ship: ";
            cin2 >> four_hit_end.first;

            cout << "Enter ending second position for four hit ship: ";
            cin2 >> four_hit_end.second;
            
            if((repeat = CheckPosition(four_hit_end.first, 
                            four_hit_end.second)) == true)
                break;
        
            SetShip(four_hit_start.first - 1, four_hit_start.second - 1, 
                four_hit_end.first - 1, four_hit_end.second - 1, num_ship);

            num_ship++;
        }
    }
    
    hook = false;
}

bool Battleship::CheckPosition(int first, int second)
{
    bool repeat = true;

    if(first > 0 && second < 7)
        repeat = false;
    else
        cout << "Please enter valid position (1-6)\n";

    return repeat;
}

void Battleship::PrintBoard()
{
    for (int i = 0; i < 6; i++)
    {
        for (int j = 0; j < 6; j++)
        {
            cout << board[i][j] << ' ';
        }
        cout << endl;
    }
}

bool Battleship::CheckMove(string move)
{
    bool check = false;
    vector<int> moves;
    
    moves = SplitMove(move);
    
    cout << "Split moves: " << moves[0] << ' ' << moves[1] << endl;
    
    //check if move is valid
    if((CheckPosition(moves[0], moves[1])) == false)
    {
        //find spot on board
    
        if(board[moves[0] - 1][moves[1] - 1] == 0)
        {
            cout << "Miss\n";
            board[moves[0] ][moves[1] ] = 0;    
        }
        else
        {
            num_hits++;
            
            board[moves[0] - 1][moves[1] - 1] = 0;    
            
            if (num_hits == MAX_HITS)
            {
                won = true;
                cout << "You lose, all your ships have sunk!\n";
                //message to other player that they have won!
            }
        }
                
        
    }
    else
    {
        //return message that their move is invalid
    }
    return check;
}

vector<int> Battleship::SplitMove(string move)
{
    vector<int> moves;
    stringstream ss(move);
    
    int count;
    
    while(ss >> count)
    {
        moves.push_back(count);
        
        if(ss.peek() == ',' || ss.peek() == ' ')
            ss.ignore();
            
    }
    
    return moves;
}

bool Battleship::CheckWin()
{        
    return won;
}
