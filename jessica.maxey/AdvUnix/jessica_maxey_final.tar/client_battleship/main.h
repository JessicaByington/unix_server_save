#pragma once
#include <condition_variable>
using std::condition_variable;

#include <mutex>
using std::mutex;

#include <string>
using std::string;

#include <sstream>
using std::stringstream;

extern bool hook;
extern stringstream cin2;