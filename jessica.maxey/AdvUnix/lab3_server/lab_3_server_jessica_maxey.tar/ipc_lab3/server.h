/********************************************************************
 *  Author:         Jessica Maxey
 *  Filename:       server.h
 *  Date Created:   5/8/2016
 *  Modifications:
 * *****************************************************************/
#include <string>
using std::string;

#include <vector>
using std::vector;

#include <thread>
using std::thread;

#include <map>
using std::map;

#include <mutex>
using std::mutex;


class server
{
    public:
    //ctor
    server();

    //dstructor
    ~server();
    void StartServer(int, int);
    void StopServer();
    void CleanUp();
    
    
private: 
    int connect_socket;
    map<string, int> clients;
    vector<thread> client_threads;
    std::unique_ptr<thread> listen_thread;
    mutex access_lock;
    bool done;
    void ListenServer();
    void ReadClient(int, string);
};
