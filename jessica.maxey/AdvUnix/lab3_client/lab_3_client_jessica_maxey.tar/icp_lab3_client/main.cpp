/*****************************************************************
 *  Author:         Jessica Maxey
 *  Filename:       main.cpp
 *  Date Created:   5/8/2016
 *  Modifications:
 * ***************************************************************
 * ***************************************************************
 *  
 *  Lab/Assignment: Lab 03 - Interprocess Communication
 *
 *  Overview: 
 *      This program will use sockets to communicate through a
 *      server to other clients connect to it. It is a basic 
 *      chat program.
 *
 *  Input:
 *      User will be ablet to specify the port and the server 
 *      it wants to connect to, and be able to send a 
 *      string message across the server to other client. 
 *
 *  Output:
 *      Clients will recieve back the message that they typed out,
 *      as well as any other messages sent to the server.
 * **************************************************************/
#include <unistd.h>

#include <string>
using std::string;

#include <iostream>
using std::cin;

#include <thread>
using std::thread;

#include "client.h"

void HandleConsole() {
    while (1) {
        string input;
        
        getline(cin, input);
        
        if (input == "stop")
        {
            StopClient();
            break;
        }
        
        WriteClient(input);
    }
}

int main (int argc, char ** argv)
{
    if(argc < 3)
    {
        fprintf(stderr, "Wrong number of args, exiting\n");
        return 0;
    }
    
    int port = atoi(argv[1]);
    string host_name = argv[2];

    CreateClient(host_name, port);
    
    auto console_thread = thread(HandleConsole);
    
    while (1)
        if (ClientConnected() == false)
            exit(0);
        else
            usleep(1000);
    
    return 0;
}
